import geopandas as gpd
from shapely.ops import nearest_points
import pandas as pd

# Caminhos dos shapefiles
pontos_path = r"C:\Users\natan\OneDrive\Desktop\mestrado\mest2\resultados_comparativos_filtrado-ok\pontos_sobrepostos.shp"
agua_path = r"C:\Users\natan\OneDrive\Desktop\mestrado\mest2\hidrografia\agua_rec.shp"
linhas_path = r"C:\Users\natan\OneDrive\Desktop\mestrado\mest2\alti\linhas.shp"

# Carregar shapefiles
gdf_pontos = gpd.read_file(pontos_path)
gdf_agua = gpd.read_file(agua_path)
gdf_linhas = gpd.read_file(linhas_path)

# Garantir que todos estão no mesmo CRS projetado
if gdf_pontos.crs != gdf_agua.crs:
    gdf_agua = gdf_agua.to_crs(gdf_pontos.crs)
if gdf_pontos.crs != gdf_linhas.crs:
    gdf_linhas = gdf_linhas.to_crs(gdf_pontos.crs)

# Verificar se o CRS é projetado (em metros). Se for geográfico (graus), reprojetar para UTM
if gdf_pontos.crs.is_geographic:
    # Exemplo: UTM 24S (Bahia). Ajuste conforme sua área
    gdf_pontos = gdf_pontos.to_crs("EPSG:31984")
    gdf_agua = gdf_agua.to_crs("EPSG:31984")
    gdf_linhas = gdf_linhas.to_crs("EPSG:31984")

# Função para calcular a geometria mais próxima
def nearest(row, other_gdf):
    nearest_geom = other_gdf.geometry.iloc[other_gdf.geometry.distance(row.geometry).idxmin()]
    return row.geometry.distance(nearest_geom)

# Calcular distância para cursos d'água
gdf_pontos["dist_agua_m"] = gdf_pontos.apply(lambda row: nearest(row, gdf_agua), axis=1)

# Calcular distância para linhas de altitude
gdf_pontos["dist_altitude_m"] = gdf_pontos.apply(lambda row: nearest(row, gdf_linhas), axis=1)

# Exportar para Excel
output_path = r"C:\Users\natan\OneDrive\Desktop\mestrado\mest2\distancias_pontos.xlsx"
gdf_pontos.drop(columns="geometry").to_excel(output_path, index=False)

print(f"Planilha exportada para: {output_path}")
