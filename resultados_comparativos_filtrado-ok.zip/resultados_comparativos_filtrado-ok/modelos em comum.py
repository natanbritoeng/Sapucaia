import geopandas as gpd

# Caminhos dos arquivos shapefile
shp1_path = r"C:\Users\natan\OneDrive\Desktop\mestrado\mest2\resultados_comparativos_filtrado-ok\rf_outputs\shapes_intersecao_pixels_rf.shp"
shp2_path = r"C:\Users\natan\OneDrive\Desktop\mestrado\mest2\resultados_comparativos_filtrado-ok\svm_outputs\shapes_intersecao_pixels_svm.shp"

# Carregar os shapefiles como GeoDataFrames
gdf1 = gpd.read_file(shp1_path)
gdf2 = gpd.read_file(shp2_path)

# Certificar que ambos usam o mesmo CRS
if gdf1.crs != gdf2.crs:
    gdf2 = gdf2.to_crs(gdf1.crs)

# Realizar a junção espacial para encontrar pontos sobrepostos
overlap = gpd.sjoin(gdf1, gdf2, how="inner", predicate="intersects")

# Contar quantos pontos se sobrepõem
count_overlap = len(overlap)
print(f"Número de pontos sobrepostos: {count_overlap}")

# Caminho para salvar os pontos em comum
output_path = r"C:\Users\natan\Downloads\pontos_sobrepostos.shp"

# Exportar shapefile
overlap.to_file(output_path, driver="ESRI Shapefile")
print(f"Shapefile exportado para: {output_path}")

