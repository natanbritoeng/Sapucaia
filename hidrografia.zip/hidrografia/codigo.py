import os
import geopandas as gpd
import pandas as pd
from shapely.ops import nearest_points

# Definindo o diretório base onde os arquivos estão localizados
base_dir = r"E:\mestrado\mest3\resultados_comparativos_filtrado\rf_outputs"

# Caminho do shapefile de linhas (hidrografia)
caminho_linhas = os.path.join(base_dir, "agua_rec.shp")

# Caminhos dos shapefiles de pontos
shapes_pontos = {
    "2020": os.path.join(base_dir, "shapes_alvo_centroides_2020_rf.shp"),
    "2023": os.path.join(base_dir, "shapes_alvo_centroides_2023_rf.shp"),
    "20-23": os.path.join(base_dir, "shapes_intersecao_centroides_rf.shp")
}

# Lê o shapefile de linhas
gdf_linhas = gpd.read_file(caminho_linhas)

# Converte o CRS para um sistema projetado, como UTM (por exemplo, EPSG 31983 para zona 23S)
if gdf_linhas.crs.is_geographic:
    gdf_linhas = gdf_linhas.to_crs(epsg=31984)  # UTM zona 24S
    print("Linhas convertidas para UTM 24S.")

# Garante que o CRS dos pontos seja o mesmo das linhas
for ano, caminho_pontos in shapes_pontos.items():
    gdf_pontos = gpd.read_file(caminho_pontos)

    if gdf_pontos.crs.is_geographic:
        gdf_pontos = gdf_pontos.to_crs(epsg=31984)  # UTM zona 24S
        print(f"Pontos de {ano} convertidos para UTM 24S.")

    # Verifica se o CRS das linhas e pontos são iguais, se não, converte
    if gdf_linhas.crs != gdf_pontos.crs:
        gdf_pontos = gdf_pontos.to_crs(gdf_linhas.crs)

    # Unifica todas as linhas em uma única geometria
    linhas_unificadas = gdf_linhas.unary_union

    # Função para calcular a distância entre o ponto e a linha mais próxima
    def calcular_distancia(ponto, linhas_unificadas):
        ponto_proximo = nearest_points(ponto, linhas_unificadas)[1]  # pega o ponto mais próximo da linha
        return ponto.distance(ponto_proximo)

    # Calcula a distância de cada ponto até a linha mais próxima
    gdf_pontos['dist_m'] = gdf_pontos.geometry.apply(lambda x: calcular_distancia(x, linhas_unificadas))

    # Salva os resultados em um novo shapefile
    gdf_pontos.to_file(f"pontos_com_distancia_{ano}.shp")
    
    # Salva as distâncias em um arquivo Excel
    gdf_pontos[['dist_m']].to_excel(f"distancia_pontos_{ano}.xlsx", index=False)

    print(f"Distância calculada e salva para {ano} com sucesso!")

    # Agrupando por faixas de 10 metros e calculando a contagem de pontos em cada faixa
    faixas = pd.cut(gdf_pontos['dist_m'], bins=range(0, int(gdf_pontos['dist_m'].max()) + 10, 10), right=False)
    quantitativos = faixas.value_counts().sort_index()

    # Convertendo para DataFrame e salvando em uma segunda planilha
    quantitativos_df = pd.DataFrame(quantitativos).reset_index()
    quantitativos_df.columns = ['Faixa de Distância (m)', 'Quantidade de Pontos']
    quantitativos_df.to_excel(f"quantitativos_faixas_{ano}.xlsx", index=False)

    print(f"Planilha com quantitativos por faixa de distância salva para {ano} com sucesso!")
