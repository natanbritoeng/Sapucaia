import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import re
import os

# ===================== DADOS =====================
arquivos = {
    "RF": r"C:\mestr\hidrografia\rf\rf_todos.xlsx",
    "SVM": r"C:\mestr\hidrografia\svm\svm_todos.xlsx",
    "KNN": r"C:\mestr\hidrografia\knn\knn_todos.xlsx",
    "Stacking": r"C:\mestr\hidrografia\stacking\stacking_todos.xlsx",
    "Voting": r"C:\mestr\hidrografia\voting\voting_todos.xlsx"
}

# --- Definir diretório para salvar os gráficos ---
primeiro_arquivo = list(arquivos.values())[0]
diretorio_saida = os.path.dirname(os.path.dirname(primeiro_arquivo))
print(f"Os gráficos serão salvos em: {diretorio_saida}\n")

todos_dados = []

for modelo, caminho in arquivos.items():
    df = pd.read_excel(caminho)
    df.columns = [str(c).strip() for c in df.columns]
    
    for ano_idx, ano in enumerate(["2020", "2023", "2020-2023"]):
        col_faixa_idx = ano_idx * 2
        col_qtd_idx = ano_idx * 2 + 1
        
        if col_faixa_idx < len(df.columns) and col_qtd_idx < len(df.columns):
            col_faixa = df.columns[col_faixa_idx]
            col_qtd = df.columns[col_qtd_idx]
            
            if df[col_faixa].notna().sum() > 0 and df[col_qtd].notna().sum() > 0:
                df_ano = pd.DataFrame({
                    "Faixa": df[col_faixa],
                    "Qtd": df[col_qtd],
                    "Ano": ano,
                    "Modelo": modelo
                })
                df_ano = df_ano.dropna(subset=['Faixa', 'Qtd'])
                todos_dados.append(df_ano)

dados = pd.concat(todos_dados, ignore_index=True)

# ===================== CORRIGIR FUNÇÃO DE EXTRAÇÃO =====================
def extrair_max_faixa_corrigido(valor):
    try:
        if pd.isna(valor): return 0
        valor_str = str(valor).strip()
        padrao_intervalo = r'\[(\d+)\s*,\s*(\d+)\)?'
        match = re.search(padrao_intervalo, valor_str)
        if match:
            return max(float(match.group(1)), float(match.group(2)))
        else:
            numeros = re.findall(r'\d+', valor_str)
            return max(float(n) for n in numeros) if numeros else 0
    except:
        return 0

dados['Max_Faixa'] = dados['Faixa'].apply(extrair_max_faixa_corrigido)

# ===================== FILTRAR ATÉ 500m =====================
dados_500m = dados[dados['Max_Faixa'] <= 500].copy()

# ================================================================= #
# --- NOVO: REAGRUPAR DADOS EM INTERVALOS DE 50m ---
# ================================================================= #
print("Reagrupando dados em intervalos de 50 metros para a plotagem...")

# 1. Definir os 'bins' (cestos) de 0 a 500, de 50 em 50
bins = np.arange(0, 501, 50) 
# Ex: [0, 50, 100, 150, 200, 250, 300, 350, 400, 450, 500]

# 2. Criar rótulos para esses bins
labels = [f'{bins[i]}-{bins[i+1]}m' for i in range(len(bins)-1)]
# Ex: ['0-50m', '50-100m', '100-150m', ...]

# 3. Criar uma nova coluna que atribui cada linha a um bin de 50m
# Usamos `right=False` para que o intervalo seja [0, 50), [50, 100), etc.
# O valor 50 cairá no grupo '50-100m', que é o comportamento esperado.
dados_500m['Faixa_50m'] = pd.cut(x=dados_500m['Max_Faixa'], bins=bins, labels=labels, right=False, include_lowest=True)

# 4. Agrupar por Ano, Modelo e a nova Faixa_50m, somando as quantidades
dados_agrupados = dados_500m.groupby(
    ['Ano', 'Modelo', 'Faixa_50m']
)['Qtd'].sum().reset_index()

print("Dados reagrupados com sucesso.\n")
# ================================================================= #


# ===================== PLOT E EXPORTAÇÃO INDIVIDUAL (COM DADOS AGRUPADOS) =====================
anos = ["2020", "2023", "2020-2023"]

cores = {"RF": "tab:blue", "SVM": "tab:orange", "KNN": "tab:green", 
         "Stacking": "tab:red", "Voting": "tab:purple"}
estilos = {"RF": "-", "SVM": "--", "KNN": "-.", "Stacking": ":", "Voting": "-"}
marcadores = {"RF": "o", "SVM": "s", "KNN": "^", "Stacking": "D", "Voting": "v"}

for ano in anos:
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # --- ALTERAÇÃO: Usar os dados agrupados ---
    dados_ano = dados_agrupados[dados_agrupados['Ano'] == ano]
    
    if dados_ano.empty:
        print(f"AVISO: Nenhum dado disponível para o ano {ano} (até 500m). O gráfico não será gerado.")
        plt.close(fig)
        continue
    
    # Não precisa mais ordenar, pois a categoria 'Faixa_50m' já é ordenada
    
    for modelo in dados_ano["Modelo"].unique():
        subset = dados_ano[dados_ano["Modelo"] == modelo]
        
        # Ignorar faixas com quantidade igual a 0 na plotagem
        subset_plot = subset[subset['Qtd'] > 0]

        if subset_plot.empty:
            continue
            
        # --- ALTERAÇÃO: Usar a nova faixa como eixo X ---
        faixas = subset_plot["Faixa_50m"].astype(str)
        
        ax.plot(faixas, subset_plot["Qtd"], 
                marker=marcadores[modelo], linestyle=estilos[modelo], 
                label=modelo, color=cores.get(modelo, "black"),
                markersize=8, linewidth=2.0) # Linha um pouco mais grossa
    
    ax.set_title(f"Comparação dos Modelos ({ano}) - Intervalos de 50m", fontsize=16, fontweight='bold', pad=20)
    ax.set_xlabel("Faixa de Distância (metros)", fontsize=12)
    ax.set_ylabel("Quantidade de Pontos (Soma)", fontsize=12)
    ax.tick_params(axis='x', rotation=45, labelsize=10) # Rotação menor para melhor leitura
    ax.grid(True, linestyle="--", alpha=0.7)
    
    if not dados_ano[dados_ano['Qtd'] > 0].empty:
        y_max = max(dados_ano["Qtd"])
        ax.set_ylim(0, y_max * 1.25)
    else:
        ax.set_ylim(0, 1)

    if len(ax.get_lines()) > 0:
      ax.legend(title="Modelos", loc="upper left", fontsize=11, title_fontsize=12)
    
    nome_arquivo = f"grafico_comparativo_{ano}_intervalos_50m.png"
    caminho_salvar = os.path.join(diretorio_saida, nome_arquivo)
    
    plt.tight_layout()
    plt.savefig(caminho_salvar, dpi=300, bbox_inches='tight')
    plt.close(fig)
    
    print(f"✓ Gráfico (intervalos 50m) salvo com sucesso: {caminho_salvar}")


# ===================== ESTATÍSTICAS =====================
# Esta seção continua mostrando as estatísticas dos dados originais (não agrupados)
print("\n=== ESTATÍSTICAS DETALHADAS (DADOS ORIGINAIS) ===")
for ano in anos:
    dados_ano_orig = dados_500m[dados_500m['Ano'] == ano]
    print(f"\n{ano}:")
    if dados_ano_orig.empty:
        print("  ⚠️  NENHUM DADO")
    else:
        print(f"  ✓ {len(dados_ano_orig)} registros")
        print(f"  Modelos presentes: {', '.join(dados_ano_orig['Modelo'].unique())}")
        print(f"  Faixas únicas: {len(dados_ano_orig['Faixa'].unique())}")
        print(f"  Valores máximos extraídos: {sorted(dados_ano_orig['Max_Faixa'].unique())}")
        
        faixas_exemplo = dados_ano_orig['Faixa'].unique()[:5]
        print(f"  Exemplo de faixas: {faixas_exemplo}")
