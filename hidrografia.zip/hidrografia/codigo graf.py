import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Caminho do arquivo Excel
file_path = r"E:\mestrado\mest3\hidrografia\rf\rf_todos.xlsx"

# Ler a planilha
df = pd.read_excel(file_path)


# Selecionar as colunas corretas
# Selecionar as colunas relevantes
df_clean = df[['Faixa de Distância (m) 2020', 'Quantidade de Pontos 2020',
               'Quantidade de Pontos 2023', 'Quantidade de Pontos 20-23']]

# Renomear para simplificar
df_clean.columns = ['Distância', 'Pontos_2020', 'Pontos_2023', 'Diferença']

df_clean = df_clean.head(50)  # Mostra só as 5 primeiras faixas

# Criar gráfico com 3 barras por grupo
x = np.arange(len(df_clean['Distância']))
largura = 0.35
fig, ax = plt.subplots(figsize=(12, 6))

# Barras
b1 = ax.bar(x - largura, df_clean['Pontos_2020'], largura, label='2020')
b2 = ax.bar(x, df_clean['Pontos_2023'], largura, label='2023')
b3 = ax.bar(x + largura, df_clean['Diferença'], largura, label='2020-2023')

# Configurações
ax.set_xlabel('Faixa de Distância (m)')
ax.set_ylabel('Quantidade de indivíduos')
ax.set_title('Comparação RF: Quantidade de Pontos por Faixa de Distância')
ax.set_xticks(x)
ax.set_xticklabels(df_clean['Distância'], rotation=90)
ax.legend()

plt.tight_layout()
plt.show()
