import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import re
import os

# ===================== DADOS =====================
arquivos = {
    "RF": r"C:\mestr\hidrografia\rf\rf_todos.xlsx",
    "SVM": r"C:\mestr\hidrografia\svm\svm_todos.xlsx",
    "KNN": r"C:\mestr\hidrografia\knn\knn_todos.xlsx",
    "Stacking": r"C:\mestr\hidrografia\stacking\stacking_todos.xlsx",
    "Voting": r"C:\mestr\hidrografia\voting\voting_todos.xlsx"
}

# --- Definir diretório para salvar os gráficos ---
primeiro_arquivo = list(arquivos.values())[0]
diretorio_saida = os.path.dirname(os.path.dirname(primeiro_arquivo))
print(f"Os gráficos serão salvos em: {diretorio_saida}\n")

todos_dados = []

for modelo, caminho in arquivos.items():
    df = pd.read_excel(caminho)
    df.columns = [str(c).strip() for c in df.columns]
    
    for ano_idx, ano in enumerate(["2020", "2023", "2020-2023"]):
        col_faixa_idx = ano_idx * 2
        col_qtd_idx = ano_idx * 2 + 1
        
        if col_faixa_idx < len(df.columns) and col_qtd_idx < len(df.columns):
            col_faixa = df.columns[col_faixa_idx]
            col_qtd = df.columns[col_qtd_idx]
            
            if df[col_faixa].notna().sum() > 0 and df[col_qtd].notna().sum() > 0:
                df_ano = pd.DataFrame({
                    "Faixa": df[col_faixa],
                    "Qtd": df[col_qtd],
                    "Ano": ano,
                    "Modelo": modelo
                })
                df_ano = df_ano.dropna(subset=['Faixa', 'Qtd'])
                todos_dados.append(df_ano)

dados = pd.concat(todos_dados, ignore_index=True)

# ===================== CORRIGIR FUNÇÃO DE EXTRAÇÃO =====================
def extrair_max_faixa_corrigido(valor):
    try:
        if pd.isna(valor): return 0
        valor_str = str(valor).strip()
        padrao_intervalo = r'\[(\d+)\s*,\s*(\d+)\)?'
        match = re.search(padrao_intervalo, valor_str)
        if match:
            return max(float(match.group(1)), float(match.group(2)))
        else:
            numeros = re.findall(r'\d+', valor_str)
            return max(float(n) for n in numeros) if numeros else 0
    except:
        return 0

dados['Max_Faixa'] = dados['Faixa'].apply(extrair_max_faixa_corrigido)

# ===================== FILTRAR ATÉ 500m =====================
dados_500m = dados[dados['Max_Faixa'] <= 500].copy()

# ================================================================= #
# --- NOVO: REAGRUPAR DADOS EM INTERVALOS DE 50m ---
# ================================================================= #
print("Reagrupando dados em intervalos de 50 metros para a plotagem...")

# 1. Definir os 'bins' (cestos) de 0 a 500, de 50 em 50
bins = np.arange(0, 501, 50) 
# Ex: [0, 50, 100, 150, 200, 250, 300, 350, 400, 450, 500]

# 2. Criar rótulos para esses bins
labels = [f'{bins[i]}-{bins[i+1]}m' for i in range(len(bins)-1)]
# Ex: ['0-50m', '50-100m', '100-150m', ...]

# 3. Criar uma nova coluna que atribui cada linha a um bin de 50m
# Usamos `right=False` para que o intervalo seja [0, 50), [50, 100), etc.
# O valor 50 cairá no grupo '50-100m', que é o comportamento esperado.
dados_500m['Faixa_50m'] = pd.cut(x=dados_500m['Max_Faixa'], bins=bins, labels=labels, right=False, include_lowest=True)

# 4. Agrupar por Ano, Modelo e a nova Faixa_50m, somando as quantidades
dados_agrupados = dados_500m.groupby(
    ['Ano', 'Modelo', 'Faixa_50m']
)['Qtd'].sum().reset_index()

print("Dados reagrupados com sucesso.\n")
# ================================================================= #


# =================================================================================
# --- PLOT E EXPORTAÇÃO COM GRÁFICOS DE BARRAS AGRUPADAS (VERSÃO MELHORADA) ---
# =================================================================================
anos = ["2020", "2023", "2020-2023"]

cores = {"RF": "tab:blue", "SVM": "tab:orange", "KNN": "tab:green",
         "Stacking": "tab:red", "Voting": "tab:purple"}

for ano in anos:
    fig, ax = plt.subplots(figsize=(16, 9)) # Aumentar o tamanho para melhor visualização

    # --- Usar os dados agrupados ---
    dados_ano = dados_agrupados[dados_agrupados['Ano'] == ano]

    if dados_ano.empty:
        print(f"AVISO: Nenhum dado disponível para o ano {ano}. O gráfico não será gerado.")
        plt.close(fig)
        continue

    # --- Pivotar os dados para o formato ideal para barras agrupadas ---
    # Isso cria uma tabela onde as linhas são as faixas, as colunas são os modelos
    # e os valores são as quantidades. fillna(0) garante que não teremos valores nulos.
    pivot_df = dados_ano.pivot(index='Faixa_50m', columns='Modelo', values='Qtd').fillna(0)

    if pivot_df.empty:
        print(f"AVISO: Nenhum dado após pivotar para o ano {ano}. O gráfico não será gerado.")
        plt.close(fig)
        continue

    # --- Lógica para criar as barras agrupadas ---
    modelos = pivot_df.columns
    faixas = pivot_df.index
    n_modelos = len(modelos)
    x = np.arange(len(faixas))  # As posições dos grupos no eixo X
    bar_width = 0.15  # A largura de cada barra individual

    # Calcular e desenhar as barras para cada modelo, deslocando sua posição
    for i, modelo in enumerate(modelos):
        # O deslocamento posiciona cada barra do grupo lado a lado
        offset = bar_width * (i - (n_modelos - 1) / 2)
        pos = x + offset
        ax.bar(pos, pivot_df[modelo], width=bar_width, label=modelo, color=cores.get(modelo, "black"))

    # --- Melhorar a aparência do gráfico ---
    ax.set_title(f"Comparação dos Modelos ({ano}) - Intervalos de 50m", fontsize=18, fontweight='bold', pad=20)
    ax.set_xlabel("Faixa de Distância (metros)", fontsize=14, labelpad=15)
    ax.set_ylabel("Quantidade de Pontos (Soma)", fontsize=14, labelpad=15)

    # Configurar os ticks do eixo X para ficarem no centro dos grupos de barras
    ax.set_xticks(x)
    ax.set_xticklabels(faixas, rotation=45, ha='right')
    ax.tick_params(axis='both', which='major', labelsize=12)

    ax.grid(True, which='major', axis='y', linestyle="--", alpha=0.7)
    ax.set_axisbelow(True) # Coloca a grade atrás das barras

    # Ajustar o limite do eixo Y para dar espaço
    y_max = pivot_df.values.max()
    ax.set_ylim(0, y_max * 1.15)

    # Adicionar legenda
    ax.legend(title="Modelos", loc="upper left", fontsize=11, title_fontsize=12)
    
    # Adicionar rótulos de valor em cima das barras (opcional, mas útil)
    for i, modelo in enumerate(modelos):
        offset = bar_width * (i - (n_modelos - 1) / 2)
        pos = x + offset
        for j, valor in enumerate(pivot_df[modelo]):
            if valor > 0: # Mostrar rótulo apenas se for maior que zero
                ax.text(pos[j], valor + (y_max * 0.01), f'{int(valor)}', ha='center', va='bottom', fontsize=8)


    # --- Salvar o gráfico ---
    nome_arquivo = f"grafico_barras_comparativo_{ano}_intervalos_50m.png"
    caminho_salvar = os.path.join(diretorio_saida, nome_arquivo)

    plt.tight_layout()
    plt.savefig(caminho_salvar, dpi=300, bbox_inches='tight')
    plt.close(fig)

    print(f"✓ Gráfico de BARRAS salvo com sucesso: {caminho_salvar}")
# ===================== ESTATÍSTICAS =====================
# Esta seção continua mostrando as estatísticas dos dados originais (não agrupados)
print("\n=== ESTATÍSTICAS DETALHADAS (DADOS ORIGINAIS) ===")
for ano in anos:
    dados_ano_orig = dados_500m[dados_500m['Ano'] == ano]
    print(f"\n{ano}:")
    if dados_ano_orig.empty:
        print("  ⚠️  NENHUM DADO")
    else:
        print(f"  ✓ {len(dados_ano_orig)} registros")
        print(f"  Modelos presentes: {', '.join(dados_ano_orig['Modelo'].unique())}")
        print(f"  Faixas únicas: {len(dados_ano_orig['Faixa'].unique())}")
        print(f"  Valores máximos extraídos: {sorted(dados_ano_orig['Max_Faixa'].unique())}")
        
        faixas_exemplo = dados_ano_orig['Faixa'].unique()[:5]
        print(f"  Exemplo de faixas: {faixas_exemplo}")
