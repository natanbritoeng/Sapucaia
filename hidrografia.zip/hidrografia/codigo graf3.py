import pandas as pd
import matplotlib.pyplot as plt

# ===================== DADOS =====================
arquivos = {
    "RF": r"C:\mestr\hidrografia\rf\rf_todos.xlsx",
    "SVM": r"C:\mestr\hidrografia\svm\svm_todos.xlsx",
    "KNN": r"C:\mestr\hidrografia\knn\knn_todos.xlsx",
    "Stacking": r"C:\mestr\hidrografia\stacking\stacking_todos.xlsx",
    "Voting": r"C:\mestr\hidrografia\voting\voting_todos.xlsx"
}

dfs = []

for modelo, caminho in arquivos.items():
    df = pd.read_excel(caminho)
    df.columns = [str(c).strip() for c in df.columns]
    
    df_long = pd.DataFrame({"Faixa": df.iloc[:, 0], "Qtd": df.iloc[:, 1], "Ano": "2020"})
    df_long2 = pd.DataFrame({"Faixa": df.iloc[:, 2], "Qtd": df.iloc[:, 3], "Ano": "2023"})
    df_long3 = pd.DataFrame({"Faixa": df.iloc[:, 4], "Qtd": df.iloc[:, 5], "Ano": "2020-2023"})
    
    df_modelo = pd.concat([df_long, df_long2, df_long3], ignore_index=True)
    df_modelo["Modelo"] = modelo
    dfs.append(df_modelo)

dados = pd.concat(dfs, ignore_index=True)

# ===================== FILTRAR ATÉ 500 M =====================
def faixa_max(f):
    """Extrai o valor máximo da faixa textual. Ex: "0-50" -> 50"""
    try:
        if isinstance(f, str):
            f = f.strip()
            if '-' in f:
                return float(f.split('-')[1])
            else:
                return float(f)
        elif pd.notnull(f):
            return float(f)
    except:
        return None

dados["Faixa_max"] = dados["Faixa"].apply(faixa_max)

# Filtra apenas faixas com limite máximo <= 500
dados_filtrados = dados[dados["Faixa_max"].notnull() & (dados["Faixa_max"] <= 500)]

# Depuração: quantos dados restaram
print("Total de linhas após filtro até 500 m:", len(dados_filtrados))

# ===================== PLOT =====================
fig, axes = plt.subplots(1, 3, figsize=(18, 6), sharey=True)
anos = ["2020", "2023", "2020-2023"]

cores = {
    "RF": "tab:blue",
    "SVM": "tab:orange",
    "KNN": "tab:green",
    "Stacking": "tab:red",
    "Voting": "tab:purple"
}

for ax, ano in zip(axes, anos):
    for modelo in dados_filtrados["Modelo"].unique():
        subset = dados_filtrados[(dados_filtrados["Modelo"] == modelo) & (dados_filtrados["Ano"] == ano)]
        if subset.empty:
            continue
        subset = subset.sort_values("Faixa_max")
        ax.plot(subset["Faixa"].astype(str), subset["Qtd"], 
                marker="o", linestyle='-', label=modelo, color=cores.get(modelo, "black"))
    
    ax.set_title(f"Comparação dos Modelos ({ano})")
    ax.set_xlabel("Faixa de Distância (m)")
    ax.grid(True, linestyle="--", alpha=0.6)

axes[0].set_ylabel("Quantidade de Pontos")

handles, labels = axes[-1].get_legend_handles_labels()
if handles:
    axes[-1].legend(handles, labels, title="Modelos", bbox_to_anchor=(1.05, 1), loc="upper left")

plt.suptitle("Comparação dos Modelos por Faixa de Distância (até 500 m)", fontsize=14)
plt.tight_layout(rect=[0, 0, 1, 0.95])
plt.show()
