import pandas as pd
import matplotlib.pyplot as plt
import numpy as np



# Caminho do arquivo Excel (use o seu caminho original aqui)
file_path = r"C:\mestr\hidrografia\svm\svm_todos.xlsx"
df = pd.read_excel(file_path)


# Selecionar as colunas relevantes
df_clean = df[['Faixa de Distância (m) 2020', 'Quantidade de Pontos 2020',
               'Quantidade de Pontos 2023', 'Quantidade de Pontos 20-23']]

# Renomear para simplificar
df_clean.columns = ['Distância', 'Pontos_2020', 'Pontos_2023', 'Diferença']

# Limitar aos 50 primeiros, conforme seu código original
df_clean = df_clean.head(50)

# Posições e largura das barras
x = np.arange(len(df_clean['Distância']))
largura = 0.25  # Largura ajustada para 3 barras

# **** ALTERAÇÃO 1: Criar figura e o primeiro eixo (ax1) ****
fig, ax1 = plt.subplots(figsize=(18, 8)) # Aumentei a largura para acomodar 50 faixas

# **** ALTERAÇÃO 2: Criar o segundo eixo (ax2) que compartilha o eixo X ****
ax2 = ax1.twinx()

# Barras plotadas no eixo principal (ax1)
b1 = ax1.bar(x - largura, df_clean['Pontos_2020'], largura, label='2020', color='royalblue')
b2 = ax1.bar(x, df_clean['Pontos_2023'], largura, label='2023', color='darkorange')

# **** ALTERAÇÃO 3: Barra 'Diferença' plotada no eixo secundário (ax2) ****
b3 = ax2.bar(x + largura, df_clean['Diferença'], largura, label='2020-2023', color='green')

# Configurações do Eixo Y Principal (Esquerda)
ax1.set_ylabel('Quantidade de Indivíduos (2020 e 2023)', fontsize=12)

# Configurações do Eixo Y Secundário (Direita)
ax2.set_ylabel('Indivíduos Estáveis (2020-2023)', color='green', fontsize=12)
ax2.tick_params(axis='y', labelcolor='green')
# Define um limite para o eixo Y secundário para melhor visualização
ax2.set_ylim(0, df_clean['Diferença'].max() * 1.15)


# Configurações gerais (Eixo X, Título, Legenda)
ax1.set_xlabel('Faixa de Distância (m)', fontsize=12)
ax1.set_title('Comparativo SVM Pontos por Faixa de Distância', fontsize=14, pad=20)
ax1.set_xticks(x)
ax1.set_xticklabels(df_clean['Distância'])
ax1.tick_params(axis='x', rotation=90, labelsize=8) # Rótulos menores e rotacionados

# **** ALTERAÇÃO 4: Unir as legendas dos dois eixos em uma só ****
bars = [b1, b2, b3]
labels = [b.get_label() for b in bars]
ax1.legend(bars, labels, loc='upper right')

fig.tight_layout() # Ajusta o layout para evitar sobreposição
plt.show()
