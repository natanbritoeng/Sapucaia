import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Caminho do arquivo Excel
file_path = r"E:\mestrado\mest3\alti\rf_todos.xlsx"

# Ler a planilha
df = pd.read_excel(file_path)

# Limpar nomes das colunas
df.columns = [str(col).strip().replace('.', '').replace(' ', '') for col in df.columns]

# Selecionar as colunas corretas
df_clean = df[['ELEV', '2020', '2023', '2020-2023']]

# Criar gráfico de barras com as 3 categorias
x = np.arange(len(df_clean['ELEV']))
largura = 0.35  # largura das barras

fig, ax = plt.subplots(figsize=(12, 6))

# Barras
ax.bar(x - largura, df_clean['2020'], largura, label='2020')
ax.bar(x, df_clean['2023'], largura, label='2023')
ax.bar(x + largura, df_clean['2020-2023'], largura, label='2020-2023')

# Configurações
ax.set_xlabel('Elevação (m)')
ax.set_ylabel('Quantidade de indivíduos')
ax.set_title('Comparação RF por Elevação: 2020, 2023 e 2020-2023')
ax.set_xticks(x)
ax.set_xticklabels(df_clean['ELEV'])
ax.legend()

plt.xticks(rotation=90)
plt.tight_layout()
plt.show()
