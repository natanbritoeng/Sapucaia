import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os

# ===================== DADOS =====================
# Dicionário com nomes dos modelos e caminhos
arquivos = {
    "RF": r"C:\mestr\alti\rf_todos.xlsx",
    "SVM": r"C:\mestr\alti\svm_todos.xlsx",
    "KNN": r"C:\mestr\alti\knn_todos.xlsx",
    "Stacking": r"C:\mestr\alti\stacking_todos.xlsx",
    "Voting": r"C:\mestr\alti\voting_todos.xlsx"
}

# --- Definir diretório para salvar os gráficos ---
primeiro_arquivo = list(arquivos.values())[0]
diretorio_saida = os.path.dirname(primeiro_arquivo)
print(f"Os gráficos serão salvos em: {diretorio_saida}\n")


# Lista para armazenar todos os DataFrames
dfs = []

for modelo, caminho in arquivos.items():
    try:
        df = pd.read_excel(caminho)
        df.columns = [str(c).strip() for c in df.columns]
        if df.shape[1] < 6:
            print(f"AVISO: O arquivo para o modelo '{modelo}' tem menos de 6 colunas. Pulando este arquivo.")
            continue
        elev = df.iloc[:, 0]
        df_long = pd.DataFrame({
            "ELEV": elev,
            "2020": df.iloc[:, 1],
            "2023": df.iloc[:, 3],
            "2020-2023": df.iloc[:, 5]
        })
        df_long = df_long.melt(id_vars="ELEV", var_name="Ano", value_name="Valor")
        df_long["Modelo"] = modelo
        dfs.append(df_long)
    except FileNotFoundError:
        print(f"ERRO: O arquivo não foi encontrado em: {caminho}")
    except Exception as e:
        print(f"ERRO ao processar o arquivo para o modelo '{modelo}': {e}")


if not dfs:
    print("\nNenhum dado foi carregado. Encerrando o script.")
    exit()

dados = pd.concat(dfs, ignore_index=True)
dados = dados.dropna(subset=['ELEV', 'Valor'])

# ===================== NOVO: AGRUPAR ELEVAÇÃO EM INTERVALOS DE 30m =====================
print("Agrupando dados em faixas de elevação de 30 metros...")

# 1. Determinar os limites para os bins
min_elev = int(np.floor(dados['ELEV'].min()))
max_elev = int(np.ceil(dados['ELEV'].max()))

# 2. Criar os bins de 30 em 30 metros
bins = np.arange(start=min_elev, stop=max_elev + 30, step=30)
labels = [f'{bins[i]}-{bins[i+1]}m' for i in range(len(bins)-1)]

# 3. Criar a nova coluna com a faixa de elevação
dados['Faixa_ELEV'] = pd.cut(x=dados['ELEV'], bins=bins, labels=labels, right=False, include_lowest=True)

# 4. Calcular a MÉDIA do "Valor" para cada grupo
# Agrupamos por Ano, Modelo e a nova Faixa de Elevação
dados_agrupados = dados.groupby(
    ['Ano', 'Modelo', 'Faixa_ELEV'],
    observed=True  # Usar observed=True para ignorar categorias vazias
)['Valor'].mean().reset_index()

print("Agrupamento concluído.\n")
# ========================================================================================


# ===================== PLOT E EXPORTAÇÃO (COM DADOS AGRUPADOS) =====================
anos = ["2020", "2023", "2020-2023"]

for ano in anos:
    fig, ax = plt.subplots(figsize=(15, 8))
    
    # MODIFICADO: Usar os dados pré-agrupados
    dados_ano = dados_agrupados[dados_agrupados['Ano'] == ano]
    
    if dados_ano.empty:
        print(f"AVISO: Nenhum dado disponível para o ano {ano}. O gráfico não será gerado.")
        plt.close(fig)
        continue
        
    # MODIFICADO: Pivotar pela nova coluna 'Faixa_ELEV'
    pivot_df = dados_ano.pivot(index='Faixa_ELEV', columns='Modelo', values='Valor').fillna(0)
    
    modelos = pivot_df.columns
    faixas = pivot_df.index
    n_modelos = len(modelos)
    x = np.arange(len(faixas))
    bar_width = 0.15

    for i, modelo in enumerate(modelos):
        offset = bar_width * (i - (n_modelos - 1) / 2)
        pos = x + offset
        ax.bar(pos, pivot_df[modelo], width=bar_width, label=modelo)

    # MODIFICADO: Títulos e rótulos para refletir a mudança
    ax.set_title(f"Comparação dos Modelos por Faixa de Elevação ({ano}, Intervalos de 30m)", fontsize=16, fontweight='bold')
    ax.set_xlabel("Faixa de Elevação", fontsize=12)
    ax.set_ylabel("Valor Médio", fontsize=12) # O valor agora é uma média
    ax.grid(True, axis='y', linestyle="--", alpha=0.7)
    
    ax.set_xticks(x)
    ax.set_xticklabels(faixas, rotation=45, ha='right')
    ax.legend(title="Modelos", loc="upper left")
    
    # MODIFICADO: Novo nome para o arquivo salvo
    nome_arquivo = f"grafico_barras_faixa_elevacao_30m_{ano.replace('-', '_')}.png"
    caminho_salvar = os.path.join(diretorio_saida, nome_arquivo)
    
    plt.tight_layout()
    plt.savefig(caminho_salvar, dpi=300)
    plt.close(fig)
    
    print(f"✓ Gráfico para o ano {ano} (intervalos 30m) salvo com sucesso em: {caminho_salvar}")
