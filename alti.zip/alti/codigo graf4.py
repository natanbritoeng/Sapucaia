import pandas as pd
import matplotlib.pyplot as plt

# Dicionário com nomes dos modelos e caminhos
arquivos = {
    "RF": r"C:\mestr\alti\rf_todos.xlsx",
    "SVM": r"C:\mestr\alti\svm_todos.xlsx",
    "KNN": r"C:\mestr\alti\knn_todos.xlsx",
    "Stacking": r"C:\mestr\alti\stacking_todos.xlsx",
    "Voting": r"C:\mestr\alti\voting_todos.xlsx"
}

# Lista para armazenar todos os DataFrames
dfs = []

for modelo, caminho in arquivos.items():
    df = pd.read_excel(caminho)
    
    # Converter nomes de colunas para string
    df.columns = [str(c).strip() for c in df.columns]
    
    # Assumindo que a primeira coluna é ELEV
    elev = df.iloc[:, 0]
    
    # Criar versão longa (tidy data)
    df_long = pd.DataFrame({
        "ELEV": elev,
        "2020": df.iloc[:, 1],
        "2023": df.iloc[:, 3],
        "2020-2023": df.iloc[:, 5]
    })
    
    # Transformar em formato long
    df_long = df_long.melt(id_vars="ELEV", var_name="Ano", value_name="Valor")
    df_long["Modelo"] = modelo
    
    dfs.append(df_long)

# Concatenar tudo
dados = pd.concat(dfs, ignore_index=True)

# ===================== PLOT =====================
fig, axes = plt.subplots(1, 3, figsize=(18, 6), sharey=True)

anos = ["2020", "2023", "2020-2023"]

for ax, ano in zip(axes, anos):
    for modelo in dados["Modelo"].unique():
        subset = dados[(dados["Modelo"] == modelo) & (dados["Ano"] == ano)]
        ax.plot(subset["ELEV"], subset["Valor"], marker="o", label=modelo)
    
    ax.set_title(f"Comparação dos Modelos ({ano})")
    ax.set_xlabel("Elevação")
    ax.grid(True, linestyle="--", alpha=0.6)

axes[0].set_ylabel("Valor")
axes[-1].legend(title="Modelos", bbox_to_anchor=(1.05, 1), loc="upper left")

plt.suptitle("Comparação dos Modelos de Classificação por Elevação (2020, 2023 e 2020-2023)", fontsize=14)
plt.tight_layout(rect=[0, 0, 1, 0.95])
plt.show()
