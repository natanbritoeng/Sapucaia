import pandas as pd
from simpledbf import Dbf5

# Caminho do arquivo DBF
caminho_arquivo = r"C:\Users\natan\OneDrive\Desktop\mestrado\mest2\resultados_comparativos_filtrado-ok\svm_outputs\2023_com_elevacao.dbf"

# Lê o arquivo DBF usando o simpledbf
dbf = Dbf5(caminho_arquivo)
df = dbf.to_dataframe()

# Verifica as colunas
print("Colunas disponíveis:", df.columns)

# Conta os indivíduos por valor de elevação
contagem = df['ELEV'].value_counts().sort_index()

# Converte para DataFrame para salvar como Excel
contagem_df = contagem.reset_index()
contagem_df.columns = ['ELEV', 'quantidade']

# Salva o resultado em um novo arquivo Excel
contagem_df.to_excel("2023svm.xlsx", index=False)

print("Arquivo 'contagem' salvo com sucesso!")
