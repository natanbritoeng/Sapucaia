import pandas as pd
import matplotlib.pyplot as plt

# Dicionário com nomes dos modelos e caminhos
arquivos = {
    "RF": r"C:\mestr\alti\rf_todos.xlsx",
    "SVM": r"C:\mestr\alti\svm_todos.xlsx",
    "KNN": r"C:\mestr\alti\knn_todos.xlsx",
    "Stacking": r"C:\mestr\alti\stacking_todos.xlsx",
    "Voting": r"C:\mestr\alti\voting_todos.xlsx"
}

# Lista para armazenar todos os DataFrames
dfs = []

for modelo, caminho in arquivos.items():
    df = pd.read_excel(caminho)
    
    # Converter nomes de colunas para string
    df.columns = [str(c).strip() for c in df.columns]
    
    # Assumindo que a primeira coluna é ELEV
    elev = df.iloc[:, 0]
    
    # Criar versão longa (tidy data)
    df_long = pd.DataFrame({
        "ELEV": elev,
        "2020": df.iloc[:, 1],
        "2023": df.iloc[:, 3],
        "2020-2023": df.iloc[:, 5]
    })
    
    # Transformar em formato long
    df_long = df_long.melt(id_vars="ELEV", var_name="Ano", value_name="Valor")
    df_long["Modelo"] = modelo
    
    dfs.append(df_long)

# Concatenar tudo
dados = pd.concat(dfs, ignore_index=True)

# ===================== PLOT =====================
plt.figure(figsize=(12, 7))

for modelo in dados["Modelo"].unique():
    subset = dados[(dados["Modelo"] == modelo) & (dados["Ano"] == "2020-2023")]
    plt.plot(subset["ELEV"], subset["Valor"], marker="o", label=modelo)

plt.title("Comparação dos Modelos por Elevação (2020-2023)")
plt.xlabel("Elevação")
plt.ylabel("Valor")
plt.legend(title="Modelo")
plt.grid(True, linestyle="--", alpha=0.6)
plt.tight_layout()
plt.show()
