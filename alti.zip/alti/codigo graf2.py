import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

file_path = r"C:\mestr\alti\stacking_todos.xlsx"
df = pd.read_excel(file_path)


# Limpar nomes das colunas
df.columns = [str(col).strip().replace('.', '').replace(' ', '') for col in df.columns]

# Selecionar as colunas corretas
df_clean = df[['ELEV', '2020', '2023', '2020-2023']]

# Posições e largura das barras
x = np.arange(len(df_clean['ELEV']))
largura = 0.25

# **** ALTERAÇÃO 1: Aumentei a largura da figura para 16 ****
fig, ax1 = plt.subplots(figsize=(16, 7))

# Criar o segundo eixo (ax2)
ax2 = ax1.twinx()

# Barras plotadas nos eixos
bar1 = ax1.bar(x - largura, df_clean['2020'], largura, label='2020', color='royalblue')
bar2 = ax1.bar(x, df_clean['2023'], largura, label='2023', color='darkorange')
bar3 = ax2.bar(x + largura, df_clean['2020-2023'], largura, label='2020-2023 (Eixo Direito)', color='green')

# Configurações do Eixo Y Principal (Esquerda)
ax1.set_ylabel('Quantidade de Indivíduos (2020 e 2023)')

# Configurações do Eixo Y Secundário (Direita)
ax2.set_ylabel('Quantidade de Indivíduos Estáveis (2020-2023)', color='green')
ax2.tick_params(axis='y', labelcolor='green')

# Configurações gerais
ax1.set_xlabel('Elevação (m)')
ax1.set_title('Comparativo STACKING por Elevação')
ax1.set_xticks(x)
ax1.set_xticklabels(df_clean['ELEV'])

# **** ALTERAÇÃO 2: Rotação e diminuição da fonte dos rótulos do eixo X ****
ax1.tick_params(axis='x', rotation=90, labelsize=8) # Reduz o tamanho da fonte para 8

# Legenda unificada
bars = [bar1, bar2, bar3]
labels = [b.get_label() for b in bars]
ax1.legend(bars, labels, loc='upper right')

# Ajusta o layout para garantir que nada seja cortado
fig.tight_layout()
plt.show()
