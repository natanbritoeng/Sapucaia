import os
import geopandas as gpd

# Caminhos fornecidos
base_dir = r"C:\Users\natan\OneDrive\Desktop\mestrado\mest2\resultados_comparativos_filtrado-ok\svm_outputs"
linhas_path = r"C:\Users\natan\OneDrive\Desktop\mestrado\alti\linhas.shp"

shapes_pontos = {
    "2020": os.path.join(base_dir, "shapes_alvo_centroides_2020_svm.shp"),
    "2023": os.path.join(base_dir, "shapes_alvo_centroides_2023_svm.shp"),
    "overlaps": os.path.join(base_dir, "shapes_intersecao_centroides_svm.shp")
}

# Função para encontrar ELEV mais próxima
def encontrar_elev_mais_proxima(ponto, gdf_linhas):
    linha_mais_proxima = gdf_linhas.geometry.distance(ponto).idxmin()
    return gdf_linhas.loc[linha_mais_proxima, 'ELEV']

# Ler linhas com ELEV
gdf_linhas = gpd.read_file(linhas_path)

# Verifica se ELEV está presente
if 'ELEV' not in gdf_linhas.columns:
    raise ValueError("A coluna 'ELEV' não foi encontrada no shapefile de linhas.")

# Converter para CRS projetado (ex: UTM zona 23S - EPSG:31983, altere se necessário)
crs_projetado = "EPSG:31984"
gdf_linhas = gdf_linhas.to_crs(crs_projetado)

# Processar cada shapefile de pontos
for nome, path_pontos in shapes_pontos.items():
    gdf_pontos = gpd.read_file(path_pontos)

    # Converter também os pontos para o mesmo CRS
    gdf_pontos = gdf_pontos.to_crs(crs_projetado)

    # Calcular elevação mais próxima
    gdf_pontos['ELEV'] = gdf_pontos.geometry.apply(lambda pt: encontrar_elev_mais_proxima(pt, gdf_linhas))

    # Salvar shapefile com ELEV
    output_path = os.path.join(base_dir, f"{nome}_com_elevacao.shp")
    gdf_pontos.to_file(output_path)

    print(f"Arquivo salvo: {output_path}")
