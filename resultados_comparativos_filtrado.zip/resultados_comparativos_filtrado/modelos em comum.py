import geopandas as gpd

# Lista com os caminhos de todos os shapefiles
shapefiles = [
    r"C:\mestr\resultados_comparativos_filtrado\rf_outputs\shapes_intersecao_pixels_rf.shp",
    r"C:\mestr\resultados_comparativos_filtrado\svm_outputs\shapes_intersecao_pixels_svm.shp",
    r"C:\mestr\resultados_comparativos_filtrado\knn_outputs\shapes_intersecao_pixels_knn.shp",
    r"C:\mestr\resultados_comparativos_filtrado\voting_outputs\shapes_intersecao_pixels_voting.shp",
    r"C:\mestr\resultados_comparativos_filtrado\stacking_outputs\shapes_intersecao_pixels_stacking.shp"
]

# Carregar shapefiles
gdfs = [gpd.read_file(shp) for shp in shapefiles]

# Padronizar CRS
for i in range(1, len(gdfs)):
    if gdfs[i].crs != gdfs[0].crs:
        gdfs[i] = gdfs[i].to_crs(gdfs[0].crs)

# Interseção cumulativa
overlap = gdfs[0]
for i in range(1, len(gdfs)):
    # Remover index_right antes da próxima junção
    if "index_right" in overlap.columns:
        overlap = overlap.drop(columns=["index_right"])
    
    overlap = gpd.sjoin(overlap, gdfs[i], how="inner", predicate="intersects")

# Remover colunas duplicadas
overlap = overlap.loc[:, ~overlap.columns.duplicated()]

# Resultado final
count_overlap = len(overlap)
print(f"Número de pontos sobrepostos em TODOS os shapefiles: {count_overlap}")

# Salvar o resultado
output_path = r"C:\mestr\resultados_comparativos_filtrado\pontos_sobrepostos_todos.shp"
overlap.to_file(output_path, driver="ESRI Shapefile")
print(f"Shapefile exportado para: {output_path}")
